#pragma once

extern int collatz_conjecture(int);
extern int test_collatz_convergence(int, int);